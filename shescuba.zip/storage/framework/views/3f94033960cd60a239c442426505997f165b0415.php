
<?php $__env->startSection('contentadmin'); ?>

<div class="col pt-7">
    <div class="card p-3">
        <h3>Form Edit Trips</h3>
        <hr>
        <form action="<?php echo e(route('admin.trip.edittrips.put', $trips->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="example-text-input" class="form-control-label">Title</label>
                <input class="form-control" type="text" value="<?php echo e(old('title', $trips->title)); ?>" placeholder="Input Title Dive Trips" id="example-text-input" name="title">
            </div>
            <div class="form-group">
                <label for="example-number-input" class="form-control-label">Address</label>
                <input class="form-control" type="text" id="example-number-input" placeholder="Input Address Trips" name="address" value="<?php echo e(old('address', $trips->address)); ?>">
            </div>
            <div class="form-group">
                <label for="example-tumbnail-input" class="form-control-label">Image</label>
                <input class="form-control" type="file" id="example-tumbnail-input" name="image" value="<?php echo e(old('image', $trips->image)); ?>">
            </div>


            <div class="form-group text-right">
                <a href="<?php echo e(route('admin.trips')); ?>" class="btn btn-warning">Cancel</a>
                <button class="btn btn-success" type="submit">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\shescuba\resources\views/admin/trips/edittrips.blade.php ENDPATH**/ ?>