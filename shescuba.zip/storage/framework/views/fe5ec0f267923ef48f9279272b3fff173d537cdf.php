
<?php $__env->startSection('contentadmin'); ?>
<div class="pt-7">
    <h1>Welcome, <?php echo e(auth()->user()->name); ?></h1>
    <h4>Semoga hari anda menyenangkan</h4>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\shescuba\resources\views/admin/index.blade.php ENDPATH**/ ?>