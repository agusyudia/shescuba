
<?php $__env->startSection('contentadmin'); ?>

<div class="col pt-7">
    <div class="card p-3">
        <h3>Form Edit Course</h3>
        <hr>
        <form action="<?php echo e(route('admin.editcourse.put', $divecourse->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="example-text-input" class="form-control-label">Title</label>
                <input class="form-control" name="title" value="<?php echo e(old('title', $divecourse->title)); ?>" type="text" placeholder="Input Title Dive Course" id="example-text-input">
            </div>
            <div class="form-group">
                <label for="example-text-input" class="form-control-label">Description</label>
                <textarea class="form-control" name="description" id="" cols="30" rows="5" placeholder="Input Description Dive Course" id="example-text-input"><?php echo e(old('description', $divecourse->description)); ?></textarea>
            </div>
            <div class="form-group">
                <label for="example-duration-input" class="form-control-label">Duration</label>
                <input class="form-control" type="text" placeholder="Input Duration DiveCourse" id="example-duration-input" name="duration" value="<?php echo e(old('duration', $divecourse->duration)); ?>">
            </div>
            <div class="form-group">
                <label for="example-number-input" class="form-control-label">Price</label>
                <input class="form-control" type="number" id="example-number-input" placeholder="Input Price Dive Course" name="price" value="<?php echo e(old('price', $divecourse->price)); ?>">
            </div>
            <div class="form-group">
                <label for="example-tumbnail-input" class="form-control-label">Tumbnail</label>
                <input class="form-control" type="file" id="example-tumbnail-input" name="tumbnail">
            </div>

            <div class="form-group text-right">
                <a href="<?php echo e(route('admin.divecourse')); ?>" class="btn btn-warning">Cancel</a>
                <button class="btn btn-success" type="submit">Update</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\shescuba\resources\views/admin/divecourse/editcourse.blade.php ENDPATH**/ ?>